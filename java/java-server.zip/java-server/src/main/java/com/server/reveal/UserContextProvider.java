package com.server.reveal;

import com.infragistics.reveal.sdk.api.IRVUserContext;
import com.infragistics.reveal.sdk.base.RVUserContext;
import com.infragistics.reveal.sdk.rest.RVContainerRequestAwareUserContextProvider;
import java.util.HashMap;
import jakarta.ws.rs.container.ContainerRequestContext;

public class UserContextProvider extends RVContainerRequestAwareUserContextProvider {
    @Override
    protected IRVUserContext getUserContext(ContainerRequestContext requestContext) {
		var props = new HashMap<String, Object>();
		props.put("some-property", "some-value");
		return new RVUserContext("", props); 
    }
}